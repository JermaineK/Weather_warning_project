# Spiral-Based Storm Early Warning — Project Skeleton
See README inside for usage. Install from requirements.txt, then run the src modules.
